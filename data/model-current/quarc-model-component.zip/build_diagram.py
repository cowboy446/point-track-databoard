"""Build the reusable, source-verified QuARC diagram specification."""
from pathlib import Path
import json
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'point-track-databoard/data/model-current'
OUT.mkdir(parents=True, exist_ok=True)
nodes, edges = [], []

def node(id, label, x, y, w, h, kind='box', color='peach', parent=None, **kw):
    nodes.append(dict(id=id, label=label, x=x, y=y, w=w, h=h,
                      kind=kind, color=color, parent=parent, **kw))

def edge(id, source, target, a='bottom', b='top', via=None, **kw):
    edges.append(dict(id=id, source=source, target=target, a=a, b=b, via=via or [], **kw))

node('video', 'Multi-view video', 35, 65, 525, 245, 'group', 'blue')
rgbfile = ROOT / 'dense-stage-eval-20261024/results-local/frozen/stride2/dev/clips/000/rgb.npz'
with np.load(rgbfile) as z:
    for v, key in enumerate(z.files):
        node(f'view-{v}', f'V{v+1}', 13, 53 + v*60, 30, 40, 'text', parent='video', size=19)
        for j, t in enumerate([0, 5, 10, 15]):
            p = OUT / f'view-{v}-frame-{j}.jpg'
            im = Image.fromarray(z[key][t].transpose(1, 2, 0)); im.thumbnail((180, 120))
            im.save(p, quality=85)
            node(f'frame-{v}-{j}', '', 55+j*112, 47+v*60, 105, 56, 'image',
                 parent='video', image=f'data/model-current/{p.name}')

node('dino', 'DINOv3\nImage tokenization', 735, 100, 265, 68, color='peach')
node('scene-input', 'Scene tokens', 1065, 112, 200, 42, color='green')
node('image-special', 'Camera + register tokens', 1045, 180, 240, 42, color='blue', size=19)
node('pack-add', '+', 845, 211, 38, 38, 'sum', 'purple', size=31)
edge('video-dino', 'video', 'dino', 'right', 'left', [[640,187],[640,134]])
edge('dino-pack', 'dino', 'pack-add')
edge('scene-pack', 'scene-input', 'pack-add', 'bottom', 'right', [[1165,240],[910,240],[910,230]])
edge('special-pack', 'image-special', 'pack-add', 'bottom', 'right', [[1165,252],[925,252],[925,230]])

node('encoder', 'Encoder', 690, 285, 350, 365, 'group', 'gray')
node('frame-attn', 'Per-Frame Self-Attention', 22, 52, 306, 45, color='yellow', parent='encoder')
node('frame-mlp', 'MLP', 100, 114, 150, 36, parent='encoder')
node('condition', 'View–Time Conditioning', 35, 170, 280, 43, parent='encoder', color='purple')
node('global-attn', 'Global / Register Self-Attention', 22, 235, 306, 45, parent='encoder', color='yellow', size=19)
node('global-mlp', 'MLP', 100, 296, 150, 36, parent='encoder')
node('enc-repeat', 'N Encoder Blocks', 80, 336, 240, 25, 'text', parent='encoder', size=21)
edge('pack-encoder', 'pack-add', 'frame-attn')
for s,t in [('frame-attn','frame-mlp'),('frame-mlp','condition'),('condition','global-attn'),('global-attn','global-mlp')]:
    edge(s+'-'+t, s,t)

node('queries', 'Point queries', 35, 395, 555, 365, 'group', 'purple')
fields = [('uv','(u, v)','Fourier + FC'),('tsrc','t_src','Fourier + FC'),
          ('vsrc','v_src','Embedding'),('ttgt','t_tgt','Fourier + FC'),
          ('tcam','t_cam','Fourier + FC'),('vcam','v_cam','Embedding')]
for i,(key,label,embedding) in enumerate(fields):
    node(key, label, 17+i*89, 63, 76, 44, parent='queries', color='white', size=22)
    node(key+'-embed', embedding.replace(' + ', '\n+ '), 17+i*89, 133, 76, 62,
         parent='queries', color='pink' if 'Embedding' in embedding else 'peach', size=16)
    edge(key+'-encoding',key,key+'-embed')
node('source-feature', 'Bilinear sample + FC', 200, 228, 230, 44, parent='queries', color='blue', size=20)
node('query-add', '+', 258, 300, 38, 38, 'sum', 'purple', parent='queries', size=31)
for i,(key,_,_) in enumerate(fields):
    edge(key+'-sum',key+'-embed','query-add','bottom','left',[[90+i*89,610],[80,610],[80,714]])
edge('feature-sum','source-feature','query-add')
edge('dino-source','dino','source-feature','bottom','right',[[867,188],[652,188],[652,645]],label='Source image features',labelAt=[636,365],labelAngle=90)

node('memory', 'Final scene representation', 1065, 630, 264, 106, 'group', 'green', size=19)
node('image-memory', 'Image tokens', 12, 49, 128, 42, parent='memory', color='green', size=18)
node('scene-memory', 'Scene tokens', 145, 49, 107, 42, parent='memory', color='green', size=18)
edge('encoder-memory','global-mlp','memory','right','left',[[1025,599],[1025,683]])

node('decoder','M Decoder Blocks',1150,295,310,183,'group','gray',size=23)
node('decoder-mlp','MLP',92,55,126,38,parent='decoder')
node('cross-attn','Cross-Attention',22,116,266,43,parent='decoder',color='yellow')
node('key','Key',1155,520,82,38,'pill','green')
node('value','Value',1253,520,88,38,'pill','green')
node('query','Query',1360,520,88,38,'pill','green')
for k in ['key','value','query']:edge(k+'-cross',k,'cross-attn','top','bottom',[[next(n['x']+n['w']/2 for n in nodes if n['id']==k),495]])
edge('memory-key','memory','key','top','bottom',[[1197,590]])
edge('memory-value','memory','value','top','bottom',[[1297,602]])
edge('cross-mlp','cross-attn','decoder-mlp','top','bottom')
node('query-norm','LayerNorm',1350,680,108,43,size=19)
edge('query-route','query-add','query-norm','right','left',[[615,714],[615,800],[1404,800],[1404,746],[1305,746],[1305,701]])
edge('query-norm-q','query-norm','query','top','bottom')
node('head','FC',1490,350,68,40)
edge('decoder-head','decoder-mlp','head','right','left',[[1475,369]])
node('output','Point predictions',1590,277,240,260,'group','coral',size=23)
node('xyz','XYZ position',20,74,200,38,'text',parent='output',size=23)
node('vis','Visibility',20,130,200,38,'text',parent='output',size=23)
node('confidence','Confidence',20,186,200,38,'text',parent='output',size=23)
edge('head-output','head','output','right','left',[[1574,370],[1574,407]])

spec = dict(version=1,id='quarc-gpu45-full-context',title='QuARC',width=1870,height=850,
            palette=dict(blue='#d1def4',purple='#ded6eb',gray='#f0f0ef',peach='#fde5cf',
                         yellow='#fff3d0',green='#dcead4',coral='#f4cdcb',pink='#e9c9d7',white='#ffffff'),
            nodes=nodes,edges=edges,
            provenance=dict(runtime='main-performance-20261023/runtime-main',experiment='direct-multiview-20261024',
                            route='R00 / D_ALL',source_features='DINO source grid in visual.pack.tokens',
                            memory='Final full-Omega image and scene rows, with role/time encoding',
                            decoder='Repeated cross-attention + MLP; same final evidence in every block',
                            outputs=['XYZ','confidence','visibility']))
(OUT/'architecture.json').write_text(json.dumps(spec,indent=2,ensure_ascii=False)+'\n')
print(f'{len(nodes)} nodes / {len(edges)} edges')
