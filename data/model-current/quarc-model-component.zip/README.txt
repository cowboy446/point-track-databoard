Serve this folder with a static HTTP server and open model.html.
Edit data/model-current/architecture.json. ArchitectureDiagram is exported by assets/model-editor/diagram.js.
Drag modules, double-click labels, save or import layout JSON, export SVG or native draw.io cells.
Prepared graph and images run independently of the original training dataset.
